# NEET Quest Android

A native Android wrapper around the existing NEET Quest dashboard, with a foreground study timer and optional system-wide floating timer.

## Build
Open this folder in Android Studio, sync Gradle, then Build > Build APK(s). The debug APK will be under app/build/outputs/apk/debug/app-debug.apk.

## Timer
The app's normal timer can use the notification shade. For the floating bubble over YouTube/Spotify/etc., grant Android's Display over other apps permission. The app only uses the overlay for the timer.

## Current web app
The existing dashboard is bundled offline in app/src/main/assets/neetquest/index.html, including the roadmap/tracking features already created.
